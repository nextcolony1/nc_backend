#!/bin/bash
# beempy updatenodes
cd /home/holger80/nextcolony/
/usr/bin/python3.6 -u /home/holger80/nextcolony/ncbctracker.py
