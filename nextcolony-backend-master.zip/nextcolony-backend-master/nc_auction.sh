#!/bin/bash
beempy updatenodes
cd /home/holger80/nextcolony/utils
/usr/bin/python3.6 -u /home/holger80/nextcolony/utils/ncsteemtracker.py
