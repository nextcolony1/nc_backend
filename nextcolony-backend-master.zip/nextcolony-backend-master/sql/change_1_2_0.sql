ALTER TABLE `users` ADD `stardust` BIGINT NULL AFTER `username`;
